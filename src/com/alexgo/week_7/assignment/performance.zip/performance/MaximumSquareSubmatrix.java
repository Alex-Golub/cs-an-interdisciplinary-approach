/**
 * 3. Maximum square submatrix.
 * Given an n-by-n matrix of 0s and 1s, find a contiguous square submatrix of maximum size that
 * contains only 1s.
 * The maximum square submatrix problem is related to problems that arise in databases,
 * image processing, and maximum likelihood estimation.
 * It is also a popular technical job interview question.
 * <p>
 * NOTES:
 * Size. The size of a square submatrix is its number of rows (or columns).
 * You may assume that argument to the size() method is a square matrix containing only 0s and 1s.
 * <p>
 * Contiguous. The square submatrix must be contiguous—the row indicies must be consecutive
 * and the column indices must be consecutive.
 * <p>
 * Performance. The size() method should take time proportional to n^2 in the worst case !!!
 * <p>
 * Input format. Standard input will contain a positive integer n, followed by n lines,
 * with each line containing n 0s and 1s, separated by whitespace.
 * <p>
 * Created by ag on 23-Aug-20 2:03 PM
 */
public class MaximumSquareSubmatrix {

  // Returns the size of the largest contiguous square submatrix of a[][] containing only 1s.
  public static int size(int[][] a) {
    int len = a.length;
    int maxSize = 0;
    int[][] temp = new int[len + 1][len + 1]; // wrap array a with this wrapper array

    for (int i = 1; i < len + 1; i++) {
      for (int j = 1; j < len + 1; j++) {
        if (a[i - 1][j - 1] == 1) { // calc minimum from three values and add 1 to
          int north = temp[i - 1][j];
          int northWest = temp[i - 1][j - 1];
          int west = temp[i][j - 1];
          int min = Math.min(north, Math.min(northWest, west));

          temp[i][j] = 1 + min;

          maxSize = Math
                  .max(1 + min, maxSize); // update max consecutive 1s if found more then previously
        }
        else temp[i][j] = 0; // is zero encountered ignore it at place 0 int (i,j)
      }
    }

    //    StdArrayIO.print(temp);

    return maxSize;
  }

  // Reads an n-by-n matrix of 0s and 1s from standard input
  // and prints the size of the largest contiguous square submatrix
  // containing only 1s.
  public static void main(String[] args) {
    int n = StdIn.readInt();
    int[][] a = new int[n][n];

    while (!StdIn.isEmpty())
      for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
          a[i][j] = StdIn.readInt();

    System.out.println(size(a));

    // for (int[] sub : a) System.out.println(Arrays.toString(sub));
  }
}
