public class RevesPuzzle {
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        towerOfReves(n, 'A', 'D', 'B', 'C');
    }

    private static void towerOfReves(int n, char src, char dist, char aux1, char aux2) {
        if (n == 0) return;
        if (n == 1) {
            StdOut.printf("Move disk %d from %c to %c\n", n, src, dist);
            return;
        }

        towerOfReves(n - 2, src, aux1, aux2, dist);

        StdOut.printf("Move disk %d from %c to %c\n", n - 1, src, aux2);
        StdOut.printf("Move disk %d from %c to %c\n", n, src, dist);
        StdOut.printf("Move disk %d from %c to %c\n", n, aux2, dist);
        StdOut.printf("Move disk %d from %c to %c\n", n - 1, aux2, dist);

        towerOfReves(n - 2, aux1, dist, src, aux2);
    }
}
