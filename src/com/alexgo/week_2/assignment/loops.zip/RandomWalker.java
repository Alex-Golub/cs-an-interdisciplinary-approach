public class RandomWalker {
  public static void main(String[] args) {
    int r = Integer.parseInt(args[0]);

    int x = 0, y = 0;
    int steps = 0;

    System.out.println("(" + x + ", " + y + ")");
    while (Math.abs(x) + Math.abs(y) != r) {
      double rnd = Math.random();

      // north, east, south, or west
      if      (rnd < 1.0 / 4) y++;
      else if (rnd < 2.0 / 4) x--;
      else if (rnd < 3.0 / 4) y--;
      else                    x++;
      steps++;

      System.out.println("(" + x + ", " + y + ")");
    }

    System.out.println("steps = " + steps);

  }
}
