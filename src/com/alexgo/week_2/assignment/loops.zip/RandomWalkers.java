public class RandomWalkers {
  public static void main(String[] args) {
    int r = Integer.parseInt(args[0]);
    int trials = Integer.parseInt(args[1]);

    int totalSteps = 0;

    for (int t = 1; t <= trials; t++) {
      int x = 0, y = 0;

      while (Math.abs(x) + Math.abs(y) != r) {
        double rnd = Math.random();

        if      (rnd < 1.0 / 4) y++;
        else if (rnd < 2.0 / 4) x--;
        else if (rnd < 3.0 / 4) y--;
        else                    x++;

        totalSteps++;
      }
    }

    System.out.println("average number of steps = " + (1.0 * totalSteps / trials));
  }
}
