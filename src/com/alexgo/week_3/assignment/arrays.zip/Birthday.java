public class Birthday {
  public static void main(String[] args) {
    int n = Integer.parseInt(args[0]);
    int trials = Integer.parseInt(args[1]);

    int[] count = new int[n + 2];  // track of the number of times that exactly i people entered the room

    for (int t = 0; t < trials; t++) {
      int people = 0;
      boolean[] hasBirthday = new boolean[n];  // keep track of which birthdays have been encountered so far

      while (true) {
        int bDay = (int) (Math.random() * n);
        people++;

        if (hasBirthday[bDay]) break;
        else                   hasBirthday[bDay] = true;
      }

      count[people - 1]++;

    }

    // summery
    double sum = 0, cumulative = 0;
    final double half = 0.5;
    for (int i = 0; cumulative < half; i++) {
      cumulative = sum / trials;
      System.out.println((i + 1) + "\t" + count[i] + "\t" + cumulative);
      sum += count[i + 1];
    }
  }
}