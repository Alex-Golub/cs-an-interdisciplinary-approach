public class ThueMorse {
  public static void main(String[] args) {
    int n = Integer.parseInt(args[0]);

    int[] thue = new int[n];

    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {

        if      (j == 0)     thue[j] = 0;
        else if (j % 2 == 0) thue[j] = thue[j / 2];
        else                 thue[j] = 1 - thue[j - 1];

        if (thue[j] == thue[i]) System.out.print("+");
        else                    System.out.print("-");

        if (j + 1 < n)
          System.out.print("  ");
      }
      System.out.println();
    }
  }
}